//
//  ViewController.swift
//  08_CoreDataAvecAssociations
//
//  Created by Etudiant on 20/04/2018.
//  Copyright © 2018 Ipssi. All rights reserved.
//

import UIKit
import CoreData


class ViewController: UIViewController {

    @IBOutlet weak var txtdisplay: UITextView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    func afficherTexte(_ texte: String){
        
        txtdisplay.text = texte
        
    }
    
    @IBAction func btnEffacerTouched(_ sender: Any) {
        afficherTexte("")
    }
    
    func initialiser(){
        let fm = FileManager.default
        
        var urlDatabase = fm.urls(for: .libraryDirectory, in: .userDomainMask).first!
        
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate
            else{
                print("Echec récupération appDelegate")
                return
        }
        
        let nom = appDelegate.persistentContainer.name
        
        urlDatabase.appendPathComponent("Application Support/" + nom + ".sqlite")
        
        do {
            try appDelegate.persistentContainer.persistentStoreCoordinator.destroyPersistentStore(at: urlDatabase, ofType: NSSQLiteStoreType, options: nil)
            
            afficherTexte("La base de données a été supprimée")
            
        }
        catch let erreur {
            print(erreur.localizedDescription)
        }
        
        do {
            try appDelegate.persistentContainer.persistentStoreCoordinator.addPersistentStore(ofType: NSSQLiteStoreType, configurationName: nil, at: urlDatabase, options: nil)
        }
        catch let erreur {
            print(erreur.localizedDescription)
        }
        
        let personne1 = creerPersonne(nom: "Chirac", prenom: "Jacques", age: 80)
        
        let personne2 = creerPersonne(nom: "Chirac", prenom: "Bernadette", age: 70)
        let personne3 = creerPersonne(nom: "Hollande", prenom: "Francois", age: 60)
        let personne5 = creerPersonne(nom: "Sarkozy", prenom: "Nicolas", age: 50)
        let personne6 = creerPersonne(nom: "Macron", prenom: "Emmanuel", age: 40)
        
        afficherTexte("La nouvelle base a été créée")
    }
    
    func getContext()-> NSManagedObjectContext{
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        return appDelegate.persistentContainer.viewContext
    }
    
    func creerPersonne(nom: String, prenom: String, age: Int16)-> Personne{
        
        let contexte = getContext()
        
        let personne = NSEntityDescription.insertNewObject(forEntityName: "Personne", into: contexte) as! Personne
        
        personne.nom = nom
        personne.prenom = prenom
        personne.age = age
        
        return personne
    }
    
    @IBAction func btnInitialiserTouched(_ sender: Any) {
        initialiser()
    }
    @IBAction func btnAfficherContenuTouched(_ sender: Any) {
    }
    @IBAction func btnModifierPersonneTouched(_ sender: Any) {
    }
    @IBAction func btnSupprimerPersonneTouched(_ sender: Any) {
    }
    @IBAction func btnEnleverAdresseTouched(_ sender: Any) {
    }
    @IBAction func btnSelectionnerAdresseTouched(_ sender: Any) {
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
        afficherTexte("test")
    }


}

